package exDEZ;

import java.util.Scanner;

public class Exerciciol {

   public static void main(String[] args) {
    Scanner leitura = new Scanner(System.in);
    
    
    System.out.println("Nome:");
    String aluno = leitura.nextLine();
    
    System.out.println("Nota 1:");
    int nota1 = leitura.nextInt();
    
    System.out.println("Nota 2:");
    int nota2 = leitura.nextInt();
    
    System.out.println("Nota :");
    int nota3 = leitura.nextInt();
    
    
    int MF = (nota1 + nota2 + nota3)/3;
    
    if(MF >= 6) {
    	
    	System.out.println(aluno + " (APROVADO!)");
    }
    
    if(MF >= 4 && MF < 6) {
    	
    	System.out.println(aluno + " (RECUPERAÇÃO!)");
    }
    
    if(MF < 4) {
    	
    	System.out.println(aluno + " (REPROVADO!)");
    }
    
    System.out.println("MÉDIA FINAL:" + MF);
 
   }
  }