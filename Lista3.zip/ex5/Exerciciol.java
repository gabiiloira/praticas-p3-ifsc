package ex5;

import java.util.Scanner;

public class Exerciciol {
 
 public static void main(String[] args) {
	  Scanner leitura = new Scanner(System.in);
	  
	  int x = 0;
	  
	  while(x < 100) {
		  x++;
		  System.out.println(x);
	  }
 }
}	  