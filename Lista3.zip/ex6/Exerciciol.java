package ex6;

import java.util.Scanner;

public class Exerciciol {

public static void main(String[] args) {
	 Scanner leitura = new Scanner(System.in);
		 
		int vet[] = new int[10];
		
		  int maior = 0, menor = 9999999;
		  
		for(int i = 0; i < 10; i++) {
			  System.out.println("Informe um número:");
			  vet[i] = leitura.nextInt();
			  
			if(vet[i] > maior) {
				maior = vet[i];
			}
		 }
        for(int j = 0; j < 10; j++) {
			  
				if(vet[j] < menor) {
				  menor = vet[j];
			  }
		  }
        
	  System.out.println("\n");
	  System.out.println("Número maior " + maior);
	  System.out.println("Número menor " + menor);
}
}