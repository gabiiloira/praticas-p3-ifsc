package ex2;

import java.util.Scanner;

public class Exerciciol {

	public static void main(String[] args) {
		
		// viabiliza a leitura de dados - frase/declaracao 1 VEZ
		Scanner leitura = new Scanner(System.in);

		System.out.println("Nome:");
		String nome = leitura.nextLine();

		System.out.println("Idade:");
		String idadestr = leitura.nextLine();

		// conversao de tipo
		// a variavel nao pode ser igual a outra variavel idade = idadestr
		Integer idade = Integer.valueOf(idadestr);

		System.out.println(nome);
		System.out.println(idade);

	}
}