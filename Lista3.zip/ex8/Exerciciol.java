package ex8;

import java.util.Scanner;

public class Exerciciol {

   public static void main(String[] args) {
    
      int vetor[] = new int[5];
      
      int soma = calculadoraSoma(vetor);
      
   }
   
   private static int calculadoraSoma(int[] vetor){
      
	   int soma = 0;
	   
      vetor [0] = 20;
      vetor [1] = 21;
      vetor [2] = 22;
      vetor [3] = 23;
      vetor [4] = 24;
      
      for(int i = 0; i < vetor.length; i++) {
   	   
   	   soma = soma + vetor[i];
      }
      
      System.out.println("A soma de todos os vetores: " + soma);
      
      return soma;
	 
   }
}