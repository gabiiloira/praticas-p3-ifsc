package ex3;


import java.util.Scanner;

    public class Exerciciol {
	  
	  public static void main(String[] args) {
		  Scanner leitura = new Scanner(System.in);
		  
		  System.out.println("Informe um numero:");
		  String numero = leitura.nextLine();
		  
		  Integer numerotr = Integer.valueOf(numero);
		  
		  
		  if(numerotr %2 == 0){
			  
		  System.out.println("Este número é par!");
		  
		  }
		  else{
			  
			  System.out.println("Este número é ímpar!");
		  
		  }
		 
	  }
}