package ex7;

import java.util.Scanner;

public class Exerciciol {

  public static void main(String[] args) {
    
    String [] vet = new String[10];
    
    vet [0] = "20";
    vet [1] = "21";
    vet [2] = "22";
    vet [3] = "23";
    vet [4] = "24";
    vet [5] = "25";
    vet [6] = "26";
    vet [7] = "27";
    vet [8] = "28";
    vet [9] = "29";
    
    System.out.println("NÚMEROS ARMAZENADOS NOS VETORES");
    System.out.println("===============================");
    for(int PosicaoDoVetor = 0; PosicaoDoVetor < 10; PosicaoDoVetor++) {
    	
    	System.out.print(vet[PosicaoDoVetor] + " ");
    }
    
    System.out.println("\n===============================");
  }
}