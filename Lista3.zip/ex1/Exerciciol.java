package ex1;

import java.util.Scanner;

public class Exerciciol {
	  
	  public static void main(String[] args) {
		  Scanner leitura = new Scanner(System.in);
		  
		  System.out.println("Escreva:");
		  
		  String conteudoLido = leitura.nextLine();
		  
		  System.out.println(conteudoLido);
	  }
}