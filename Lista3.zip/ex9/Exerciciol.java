package ex9;

import java.util.Scanner;

public class Exerciciol {

   public static void main(String[] args) {
    Scanner leitura = new Scanner(System.in);
    
    System.out.println("========================================");
    System.out.println("          O VALOR DA GASOLINA           ");
    System.out.println("========================================");
    System.out.println("1L ............................. R$05,00");
    System.out.println("========================================");
    System.out.println("Quantos litros você deseja abastecer:");
    int quantidadeLitros = leitura.nextInt();
    
    int soma = 0;
    int precoLitro = 5;
    
    if(quantidadeLitros > 1){
    	
    	soma = quantidadeLitros * precoLitro;
    }
    if(quantidadeLitros == 0) {
    	
    	System.out.println("Este valor é inválido!");
    	System.out.println("Repita o processo e mencione o quanto deseja abastecer!");
    }
    
    System.out.println("=====================================");
    System.out.println("O PREÇO A SE PAGAR: " + soma + " REAIS");
   }
}